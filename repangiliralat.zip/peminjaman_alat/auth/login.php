<?php
require_once __DIR__ . '/../config/koneksi.php';

// Sudah login? langsung ke dashboard masing-masing.
if (!empty($_SESSION['id_user']) && !empty($_SESSION['level'])) {
    redirect(dashboard_path($_SESSION['level']));
}

$judul = 'Masuk';
$body_class = 'bg-neutral-50';
$tanpa_layout = true;
require_once __DIR__ . '/../includes/header.php';

function logo_svg_login($kelas = 'h-11 w-11')
{
    return '<span class="grid shrink-0 place-items-center rounded-xl ' . $kelas . '" style="background:#FF7A45;border:2px solid #17130D;box-shadow:3px 3px 0 #17130D">'
        . '<svg viewBox="0 0 24 24" class="h-[62%] w-[62%]" fill="none" stroke="#17130D" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M17.5 8.5A6.5 6.5 0 1 0 18.4 14"/><path d="M18 3.5v5h-5"/></svg></span>';
}
?>
<div class="grid min-h-screen lg:grid-cols-[1.1fr_1fr]">
    <!-- Panel merek -->
    <aside class="relative hidden overflow-hidden border-r-2 border-neutral-900 p-12 lg:flex lg:flex-col lg:justify-between" style="background:#FFD84D">
        <!-- Hiasan geometri -->
        <span class="pointer-events-none absolute -right-20 top-24 h-72 w-72 rounded-full border-2 border-neutral-900" style="background:#FF7A45"></span>
        <span class="pointer-events-none absolute right-32 top-[26rem] h-28 w-28 rotate-12 rounded-2xl border-2 border-neutral-900 bg-white"></span>
        <span class="pointer-events-none absolute -bottom-12 -left-10 h-56 w-56 rounded-full border-2 border-neutral-900" style="background:#BDEFC8"></span>

        <div class="relative flex items-center gap-3">
            <?= logo_svg_login() ?>
            <span class="font-display text-3xl font-extrabold tracking-tight text-neutral-900">Gilir.</span>
        </div>

        <div class="relative max-w-lg">
            <p class="inline-block -rotate-2 rounded-md border-2 border-neutral-900 bg-white px-2.5 py-1 font-mono text-[11px] font-medium uppercase tracking-[.14em] shadow-soft">Pinjam bergiliran</p>
            <h2 class="mt-5 font-display text-5xl font-extrabold leading-[1.05] text-neutral-900">Satu alat,<br>banyak tangan.<br><span class="inline-block rounded-xl border-2 border-neutral-900 bg-white px-3 shadow-glow">Semua tercatat.</span></h2>
            <p class="mt-6 max-w-md text-base font-medium text-neutral-800">Ajukan, setujui, dan lacak setiap peminjaman alat tanpa buku catatan yang tercecer.</p>
            <ul class="mt-8 flex flex-wrap gap-2.5 text-sm font-bold">
                <?php foreach (['Ajukan cepat', 'Stok terpantau', 'Laporan siap cetak'] as $f): ?>
                    <li class="flex items-center gap-2 rounded-full border-2 border-neutral-900 bg-white px-3.5 py-1.5"><?= icon('check', 'w-3.5 h-3.5') ?><?= e($f) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <p class="relative font-mono text-xs text-neutral-800">© <?= date('Y') ?> Gilir · Sistem peminjaman alat</p>
    </aside>

    <!-- Form -->
    <div class="flex flex-col items-center justify-center px-4 py-12">
        <div class="w-full max-w-sm">
            <a href="<?= url('auth/login.php') ?>" class="mb-8 flex items-center gap-2.5 lg:hidden">
                <?= logo_svg_login('h-10 w-10') ?>
                <span class="font-display text-2xl font-extrabold tracking-tight text-neutral-900">Gilir.</span>
            </a>

            <p class="font-mono text-xs font-medium uppercase tracking-[.16em] text-accent-700">Masuk ke akun</p>
            <h1 class="mt-1 text-4xl font-extrabold text-neutral-900">Giliran kamu <span class="text-gradient">masuk</span></h1>
            <p class="mt-2 text-sm text-neutral-600">Pakai username dan password dari admin.</p>

            <div class="card mt-7 p-6 sm:p-7">
                <form action="proses_login.php" method="post" class="space-y-5">
                    <?= csrf_field() ?>
                    <div>
                        <label class="label" for="username">Username</label>
                        <input class="input" type="text" id="username" name="username" autocomplete="username" required autofocus>
                    </div>
                    <div>
                        <label class="label" for="password">Password</label>
                        <div class="relative">
                            <input class="input pr-11" type="password" id="password" name="password" autocomplete="current-password" required>
                            <button type="button" class="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-neutral-500 transition-colors hover:bg-neutral-100 hover:text-neutral-900" data-pass-toggle="#password" aria-label="Tampilkan password"><?= icon('eye', 'w-[18px] h-[18px]') ?></button>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-full py-3 text-base">Masuk <?= icon('arrow', 'w-4 h-4') ?></button>
                </form>
            </div>

            <!-- Akun contoh: hapus blok ini saat aplikasi dipakai sungguhan -->
            <div class="mt-6 rounded-2xl border-2 border-dashed border-neutral-400 p-4">
                <p class="font-mono text-[11px] font-medium uppercase tracking-[.14em] text-neutral-600">Akun contoh · klik untuk isi otomatis</p>
                <div class="mt-3 flex flex-wrap gap-2">
                    <?php foreach ([['admin', 'admin123'], ['petugas', 'petugas123'], ['peminjam', 'peminjam123']] as $ak): ?>
                        <button type="button" class="chip !px-3 !py-1 !text-xs" data-akun="<?= e($ak[0]) ?>|<?= e($ak[1]) ?>"><?= e(ucfirst($ak[0])) ?></button>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('[data-akun]').forEach(function (b) {
    b.addEventListener('click', function () {
        var p = b.getAttribute('data-akun').split('|');
        document.getElementById('username').value = p[0];
        document.getElementById('password').value = p[1];
        document.getElementById('password').focus();
    });
});
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
