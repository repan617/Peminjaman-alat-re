<?php
/**
 * includes/navbar.php
 * Navigasi "Gilir": sidebar gelap di desktop, bilah atas + menu lipat di ponsel.
 * Wajib setelah header.php dan auth.php. Ditutup oleh footer.php.
 */
$menu_aktif = basename($_SERVER['SCRIPT_NAME'], '.php');

$menus = [
    'admin' => [
        ['dashboard', 'Dashboard', 'grid'],
        ['user', 'Pengguna', 'users'],
        ['kategori', 'Kategori', 'tag'],
        ['alat', 'Data Alat', 'box'],
        ['peminjaman', 'Peminjaman', 'clipboard'],
        ['pengembalian', 'Pengembalian', 'return'],
        ['log_aktivitas', 'Log Aktivitas', 'activity'],
    ],
    'petugas' => [
        ['dashboard', 'Dashboard', 'grid'],
        ['peminjaman', 'Data Peminjaman', 'clipboard'],
        ['setujui', 'Persetujuan', 'check'],
        ['pengembalian', 'Pengembalian', 'return'],
        ['cetak', 'Cetak Laporan', 'printer'],
    ],
    'peminjam' => [
        ['dashboard', 'Beranda', 'home'],
        ['daftar_alat', 'Katalog Alat', 'grid'],
        ['pinjam', 'Ajukan Pinjam', 'plus'],
        ['riwayat', 'Riwayat', 'clock'],
    ],
];
$menu = $menus[$user['level']];

$jumlah_menunggu = 0;
if ($user['level'] !== 'peminjam') {
    $jumlah_menunggu = (int)db_val($koneksi, 'SELECT COUNT(*) FROM peminjaman WHERE persetujuan = 0');
}

/** Logo Gilir: panah melingkar = alat yang terus berputar dari tangan ke tangan. */
function logo_svg($kelas = 'w-10 h-10')
{
    return '<span class="grid shrink-0 place-items-center rounded-xl ' . $kelas . '" style="background:#FF7A45;border:2px solid #17130D;box-shadow:2px 2px 0 #FBF6EC">'
        . '<svg viewBox="0 0 24 24" class="h-[62%] w-[62%]" fill="none" stroke="#17130D" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M17.5 8.5A6.5 6.5 0 1 0 18.4 14"/><path d="M18 3.5v5h-5"/></svg></span>';
}
?>

<div class="lg:flex">

<!-- Sidebar (desktop) -->
<aside class="no-print sticky top-0 hidden h-screen w-64 shrink-0 flex-col justify-between overflow-y-auto bg-neutral-900 p-4 lg:flex">
    <div>
        <a href="<?= url($user['level'] . '/dashboard.php') ?>" class="flex items-center gap-3 px-1 pt-1">
            <?= logo_svg() ?>
            <span class="leading-none">
                <span class="block font-display text-2xl font-extrabold tracking-tight text-neutral-50">Gilir<span style="color:#FF7A45">.</span></span>
                <span class="mt-1 block font-mono text-[10px] uppercase tracking-[.16em] text-neutral-400">pinjam bergiliran</span>
            </span>
        </a>

        <p class="mb-2 mt-9 px-3 font-mono text-[10px] uppercase tracking-[.18em] text-neutral-400">Menu <?= e($user['level']) ?></p>
        <nav class="space-y-1.5" aria-label="Menu utama">
            <?php foreach ($menu as $m):
                $on = $menu_aktif === $m[0];
                $notif = ($m[0] === 'setujui' || ($user['level'] === 'admin' && $m[0] === 'peminjaman')) && $jumlah_menunggu > 0;
            ?>
                <a href="<?= url($user['level'] . '/' . $m[0] . '.php') ?>" class="nav-link <?= $on ? 'nav-on' : '' ?>" <?= $on ? 'aria-current="page"' : '' ?>>
                    <?= icon($m[2], 'w-[18px] h-[18px]') ?>
                    <span class="flex-1"><?= e($m[1]) ?></span>
                    <?php if ($notif): ?><span class="grid h-5 min-w-[1.25rem] place-items-center rounded-full border-2 border-neutral-900 bg-warn-400 px-1 font-mono text-[11px] font-bold text-neutral-900"><?= $jumlah_menunggu ?></span><?php endif; ?>
                </a>
            <?php endforeach; ?>
        </nav>
    </div>

    <div class="mt-8 rounded-2xl border-2 border-neutral-50/20 p-3">
        <div class="flex items-center gap-3">
            <span class="grid h-10 w-10 shrink-0 place-items-center rounded-full border-2 border-neutral-50 bg-warn-300 text-sm font-extrabold text-neutral-900"><?= e(inisial($user['nama'])) ?></span>
            <div class="min-w-0 leading-tight">
                <p class="truncate text-sm font-bold text-neutral-50"><?= e($user['nama']) ?></p>
                <p class="font-mono text-[11px] uppercase tracking-wide text-neutral-400"><?= e($user['level']) ?></p>
            </div>
        </div>
        <a href="<?= url('auth/logout.php') ?>" class="btn btn-ghost btn-sm mt-3 w-full" style="box-shadow:2px 2px 0 #FF7A45"><?= icon('logout', 'w-4 h-4') ?> Keluar</a>
    </div>
</aside>

<div class="min-w-0 flex-1">

<!-- Bilah atas (ponsel & tablet) -->
<header class="no-print sticky top-0 z-40 border-b-2 border-neutral-900 bg-neutral-50 lg:hidden">
    <div class="flex h-16 items-center justify-between px-4 sm:px-6">
        <a href="<?= url($user['level'] . '/dashboard.php') ?>" class="flex items-center gap-2.5">
            <?= logo_svg('w-9 h-9') ?>
            <span class="font-display text-xl font-extrabold tracking-tight text-neutral-900">Gilir<span style="color:#F2592A">.</span></span>
        </a>
        <button type="button" class="btn btn-ghost !h-10 !w-10 !p-0" data-toggle="#menu-mobile" aria-label="Buka menu"><?= icon('menu', 'w-5 h-5') ?></button>
    </div>

    <div id="menu-mobile" class="hidden border-t-2 border-dashed border-neutral-300 bg-neutral-50 px-4 pb-4 pt-3">
        <?php foreach ($menu as $m):
            $on = $menu_aktif === $m[0];
            $notif = ($m[0] === 'setujui' || ($user['level'] === 'admin' && $m[0] === 'peminjaman')) && $jumlah_menunggu > 0;
        ?>
            <a href="<?= url($user['level'] . '/' . $m[0] . '.php') ?>" class="mb-1.5 flex items-center gap-3 rounded-xl border-2 px-3 py-2.5 text-sm font-semibold text-neutral-900 <?= $on ? 'border-neutral-900 bg-accent-400 shadow-soft' : 'border-transparent hover:bg-neutral-100' ?>">
                <?= icon($m[2], 'w-[18px] h-[18px]') ?> <span class="flex-1"><?= e($m[1]) ?></span>
                <?php if ($notif): ?><span class="grid h-5 min-w-[1.25rem] place-items-center rounded-full border-2 border-neutral-900 bg-warn-400 px-1 font-mono text-[11px] font-bold"><?= $jumlah_menunggu ?></span><?php endif; ?>
            </a>
        <?php endforeach; ?>
        <div class="mt-3 flex items-center justify-between border-t-2 border-dashed border-neutral-300 pt-3">
            <span class="text-sm font-semibold text-neutral-900"><?= e($user['nama']) ?> <span class="font-mono text-xs font-medium uppercase text-neutral-500">· <?= e($user['level']) ?></span></span>
            <a href="<?= url('auth/logout.php') ?>" class="btn btn-ghost btn-sm"><?= icon('logout', 'w-4 h-4') ?> Keluar</a>
        </div>
    </div>
</header>

<main class="<?= $user['level'] === 'peminjam' ? 'min-h-[70vh]' : 'mx-auto min-h-[70vh] max-w-6xl px-4 py-8 sm:px-8' ?>">
