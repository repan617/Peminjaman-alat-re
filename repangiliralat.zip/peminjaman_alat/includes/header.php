<?php
/**
 * includes/header.php  →  <head> + Tailwind CDN + sistem desain "Gilir"
 * Gaya: kertas krem, garis tinta tebal, bayangan keras (neo-brutalist yang ramah).
 * Variabel opsional sebelum include:
 *   $judul       judul halaman
 *   $body_class  kelas tambahan untuk <body>
 */
$judul = isset($judul) ? $judul : 'Beranda';
$body_class = isset($body_class) ? $body_class : 'bg-neutral-50';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($judul) ?> · Gilir</title>
    <meta name="theme-color" content="#FBF6EC">
    <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect x='1.5' y='1.5' width='29' height='29' rx='9' fill='%23FF7A45' stroke='%2317130D' stroke-width='3'/%3E%3Cpath d='M21.5 12A7 7 0 1 0 22.5 18' fill='none' stroke='%2317130D' stroke-width='3' stroke-linecap='round'/%3E%3Cpath d='M22 6.5V12.5H16' fill='none' stroke='%2317130D' stroke-width='3' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700;12..96,800&family=DM+Sans:wght@400;500;600;700&family=DM+Mono:wght@500&display=swap" rel="stylesheet">

    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"DM Sans"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
                        display: ['"Bricolage Grotesque"', '"DM Sans"', 'ui-sans-serif', 'sans-serif'],
                        mono: ['"DM Mono"', 'ui-monospace', 'monospace']
                    },
                    colors: {
                        /* Netral hangat: 50 = kertas krem, 900 = tinta */
                        neutral: {50:'#FBF6EC',100:'#F3ECDD',200:'#E4DAC4',300:'#CFC2A5',400:'#9A8F78',500:'#6F6652',600:'#544C3B',700:'#3A3428',800:'#27221A',900:'#17130D',950:'#0B0905'},
                        /* Aksen: jingga tomat */
                        accent: {50:'#FFF1EA',100:'#FFDCCB',200:'#FFBFA3',300:'#FF9B72',400:'#FF7A45',500:'#F2592A',600:'#D9441A',700:'#B13410',800:'#85260B',900:'#5C1A07'},
                        warn: {100:'#FFF1C2',300:'#F5C84B',400:'#F2B705',500:'#D99A00',600:'#A66F00'},
                        danger: {50:'#FFF0F0',100:'#FFD9D9',500:'#E5484D',600:'#D12F3A',700:'#A8202B'}
                    },
                    boxShadow: {
                        soft: '3px 3px 0 #17130D',
                        glow: '4px 4px 0 #17130D',
                        pop: '6px 6px 0 #17130D'
                    }
                }
            }
        };
    </script>

    <style type="text/tailwindcss">
        @layer base {
            html { -webkit-tap-highlight-color: transparent; scroll-behavior: smooth; }
            body { @apply font-sans text-neutral-900 antialiased; }
            h1, h2, h3 { @apply font-display; letter-spacing: -0.02em; }
            ::selection { background: #FFD84D; color: #17130D; }
            :focus-visible { outline: 3px solid #17130D; outline-offset: 2px; border-radius: 6px; }
        }
        @layer components {
            .btn { @apply inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm font-bold whitespace-nowrap disabled:opacity-50 disabled:pointer-events-none; color: #17130D; background: #fff; border: 2px solid #17130D; box-shadow: 3px 3px 0 #17130D; transition: transform .12s ease, box-shadow .12s ease, background-color .12s ease; }
            .btn:hover { transform: translate(-1px, -1px); box-shadow: 4px 4px 0 #17130D; }
            .btn:active { transform: translate(3px, 3px); box-shadow: 0 0 0 #17130D; }
            .btn-sm { @apply px-3 py-1.5 text-xs gap-1.5; box-shadow: 2px 2px 0 #17130D; border-radius: .6rem; }
            .btn-sm:hover { box-shadow: 3px 3px 0 #17130D; }
            .btn-primary, .btn-saffron { background: #FF7A45; color: #17130D; }
            .btn-primary:hover, .btn-saffron:hover { background: #FF8D5F; }
            .btn-dark { background: #17130D; color: #FBF6EC; box-shadow: 3px 3px 0 #FF7A45; }
            .btn-dark:hover { box-shadow: 4px 4px 0 #FF7A45; }
            .btn-soft { background: #FFE9A8; }
            .btn-soft:hover { background: #FFDF7E; }
            .btn-ghost { background: #fff; }
            .btn-ghost:hover { background: #FFF3D6; }
            .btn-danger { background: #E5484D; color: #fff; }
            .btn-danger:hover { background: #D12F3A; }
            .btn-danger-soft { background: #FFE3E3; color: #A8202B; }
            .btn-danger-soft:hover { background: #FFCACA; }
            .btn.cursor-not-allowed { box-shadow: none; border-style: dashed; border-color: #9A8F78; background: transparent; color: #9A8F78; transform: none !important; }
            .input { @apply w-full rounded-xl px-3.5 py-2.5 text-sm text-neutral-900 placeholder:text-neutral-400 focus:outline-none; background: #fff; border: 2px solid #17130D; transition: box-shadow .12s ease, background-color .12s ease; }
            .input:focus { background: #FFFBEF; box-shadow: 3px 3px 0 #FF7A45; }
            select.input option { background: #fff; color: #17130D; }
            .label { @apply mb-1.5 block font-mono text-[11px] font-medium uppercase tracking-[.12em] text-neutral-600; }
            .card { @apply rounded-2xl; background: #fff; border: 2px solid #17130D; box-shadow: 4px 4px 0 #17130D; }
            a.card, article.card { transition: transform .15s ease, box-shadow .15s ease; }
            a.card:hover, article.card:hover { transform: translate(-2px, -2px); box-shadow: 6px 6px 0 #17130D; }
            .badge { @apply inline-flex items-center gap-1.5 whitespace-nowrap rounded-md px-2 py-0.5 font-mono text-[11px] font-medium uppercase tracking-wide; color: #17130D; border: 1.5px solid #17130D; }
            .badge i { @apply block h-1.5 w-1.5 rounded-full; background: #17130D; }
            .badge-amber { background: #FFE08A; }
            .badge-green { background: #BDEFC8; }
            .badge-red { background: #FFC4C4; }
            .badge-blue { background: #BFE0FF; }
            .badge-violet { background: #D9C8FF; }
            .badge-gray { background: #EFE7D3; }
            .tbl { @apply w-full text-sm; }
            .tbl th { @apply whitespace-nowrap px-5 py-3 text-left font-mono text-[11px] font-medium uppercase tracking-[.12em]; background: #17130D; color: #FBF6EC; }
            .tbl td { @apply px-5 py-3.5 align-middle; border-top: 1.5px dashed #CFC2A5; }
            .tbl tbody tr:first-child td { border-top: 0; }
            .tbl tbody tr { transition: background-color .12s ease; }
            .tbl tbody tr:hover { background: #FFF3D6; }
            .chip { @apply inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-sm font-semibold whitespace-nowrap; background: #fff; color: #17130D; border: 2px solid #17130D; transition: background-color .12s ease, transform .12s ease, box-shadow .12s ease; }
            .chip:hover { background: #FFE9A8; }
            .chip-on, .chip-on:hover { background: #FF7A45; box-shadow: 2px 2px 0 #17130D; transform: translate(-1px, -1px); }
            .icon-tile { @apply grid shrink-0 place-items-center rounded-xl; color: #17130D; background: #FFE9A8; border: 2px solid #17130D; }
            .nav-link { @apply flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold; color: #D9CFB8; border: 2px solid transparent; transition: background-color .12s ease, color .12s ease; }
            .nav-link:hover { background: rgba(251,246,236,.08); color: #FBF6EC; }
            .nav-on, .nav-on:hover { background: #FF7A45; color: #17130D; border-color: #FBF6EC; box-shadow: 3px 3px 0 #FBF6EC; }
        }
    </style>

    <style>
        body {
            background-color: #FBF6EC;
            background-image: radial-gradient(rgba(23,19,13,.13) 1px, transparent 1.2px);
            background-size: 22px 22px;
            background-attachment: fixed;
        }
        .scroll-thin::-webkit-scrollbar { width: 8px; height: 8px; }
        .scroll-thin::-webkit-scrollbar-thumb { background: #17130D; border-radius: 999px; border: 2px solid #FBF6EC; }
        /* Sorotan penanda stabilo untuk angka & kata penting */
        .text-gradient { background-image: linear-gradient(transparent 60%, #FFD84D 60%, #FFD84D 94%, transparent 94%); padding: 0 .12em; -webkit-box-decoration-break: clone; box-decoration-break: clone; color: inherit; }
        .glass { background: #FBF6EC; }
        /* Pemisah daftar: garis putus-putus */
        .divide-y.divide-neutral-100 > :not([hidden]) ~ :not([hidden]) { border-color: #CFC2A5 !important; border-top-style: dashed !important; border-top-width: 1.5px !important; }
        /* Modal */
        .modal { position: fixed; inset: 0; z-index: 60; display: none; align-items: center; justify-content: center; padding: 1rem; }
        .modal.open { display: flex; }
        .modal-bg { position: absolute; inset: 0; background: rgba(23,19,13,.55); animation: fadeIn .2s ease; }
        .modal-box { position: relative; width: 100%; max-width: 28rem; max-height: 92vh; overflow-y: auto; border-radius: 1.1rem; background: #fff; border: 2px solid #17130D; box-shadow: 8px 8px 0 #17130D; animation: pop .25s cubic-bezier(.2,.9,.3,1.2); }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes pop { from { opacity: 0; transform: translateY(12px) scale(.97); } to { opacity: 1; transform: none; } }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: none; } }
        @keyframes toastIn { from { opacity: 0; transform: translateY(-14px) rotate(-2deg); } to { opacity: 1; transform: none; } }
        @keyframes toastOut { to { opacity: 0; transform: translateY(-8px); } }
        .toast-auto { animation: toastIn .35s cubic-bezier(.2,.9,.3,1.2), toastOut .3s ease 4.7s forwards; }
        main > * { animation: fadeUp .5s cubic-bezier(.2,.7,.2,1) both; }
        main > *:nth-child(2) { animation-delay: .05s; }
        main > *:nth-child(3) { animation-delay: .1s; }
        main > *:nth-child(4) { animation-delay: .15s; }
        main > *:nth-child(n+5) { animation-delay: .2s; }
        /* Cetak: putih polos, tanpa bayangan */
        @media print {
            .no-print { display: none !important; }
            body { background: #fff !important; }
            .card { box-shadow: none !important; }
        }
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after { animation-duration: .001ms !important; transition-duration: .001ms !important; }
        }
    </style>
</head>
<body class="<?= e($body_class) ?>">
