<?php
/**
 * includes/footer.php
 * Menutup layout, menampilkan notifikasi (flash), dan memuat JS global.
 * Set $tanpa_layout = true di halaman tanpa navbar (login, cetak).
 */
$tanpa_layout = isset($tanpa_layout) ? $tanpa_layout : false;
$flash = flash_ambil();
$level_footer = isset($user['level']) ? $user['level'] : null;

if (!$tanpa_layout): ?>
</main>

<footer class="no-print mt-12 border-t-2 border-dashed border-neutral-300">
    <div class="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-6 text-xs text-neutral-500 sm:flex-row sm:items-center sm:justify-between sm:px-8">
        <p class="font-semibold text-neutral-700">© <?= date('Y') ?> Gilir<span style="color:#F2592A">.</span> <span class="font-normal text-neutral-500">Alat dipakai bergiliran, tetap rapi tercatat.</span></p>
        <?php if ($level_footer === 'peminjam'): ?>
            <p class="font-mono">Senin–Jumat, 07.30–16.00 · Ruang inventaris, lantai 1 · inventaris@sekolah.id</p>
        <?php endif; ?>
    </div>
</footer>

</div><!-- /kolom konten -->
</div><!-- /pembungkus sidebar -->
<?php endif; ?>

<?php if ($flash): ?>
<div class="pointer-events-none fixed inset-x-0 top-4 z-[70] flex justify-center px-4 no-print" role="status" aria-live="polite">
    <div id="toast" class="toast-auto pointer-events-auto flex max-w-md items-start gap-3 rounded-xl border-2 border-neutral-900 bg-white px-4 py-3 text-sm font-semibold text-neutral-900 shadow-pop">
        <span class="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border-2 border-neutral-900 <?= $flash['tipe'] === 'error' ? 'bg-danger-500 text-white' : 'bg-[#7EE0A0] text-neutral-900' ?>">
            <?= icon($flash['tipe'] === 'error' ? 'alert' : 'check', 'w-3.5 h-3.5') ?>
        </span>
        <p class="leading-snug"><?= e($flash['pesan']) ?></p>
        <button type="button" class="-mr-1 ml-1 text-neutral-500 hover:text-neutral-900" onclick="this.closest('#toast').remove()" aria-label="Tutup"><?= icon('x', 'w-4 h-4') ?></button>
    </div>
</div>
<?php endif; ?>

<!-- Dialog konfirmasi (dipakai tombol hapus, tolak, dll) -->
<div id="confirm-modal" class="modal no-print" role="dialog" aria-modal="true" aria-labelledby="confirm-judul">
    <div class="modal-bg" data-modal-close></div>
    <div class="modal-box p-6 sm:max-w-sm">
        <h3 id="confirm-judul" class="text-lg font-bold text-neutral-900">Lanjutkan tindakan ini?</h3>
        <p id="confirm-teks" class="mt-2 text-sm text-neutral-500"></p>
        <div class="mt-6 flex justify-end gap-2">
            <button type="button" class="btn btn-ghost" data-modal-close>Batal</button>
            <button type="button" id="confirm-ok" class="btn btn-danger">Ya, lanjutkan</button>
        </div>
    </div>
</div>

<script>
(function () {
    var $ = function (s, r) { return (r || document).querySelector(s); };
    var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

    /* Toggle umum */
    $$('[data-toggle]').forEach(function (el) {
        el.addEventListener('click', function () { var t = $(el.getAttribute('data-toggle')); if (t) t.classList.toggle('hidden'); });
    });

    /* Modal */
    function modal(m, buka) {
        if (!m) return;
        m.classList.toggle('open', buka);
        document.body.style.overflow = buka ? 'hidden' : '';
        if (buka) { var f = $('input:not([type=hidden]),select,textarea', m); if (f) setTimeout(function () { f.focus(); }, 60); }
    }
    $$('[data-modal-open]').forEach(function (el) {
        el.addEventListener('click', function () {
            var m = $(el.getAttribute('data-modal-open'));
            if (!m) return;
            var form = $('form', m);
            if (form) {
                form.reset();
                var data = el.getAttribute('data-json');
                data = data ? JSON.parse(data) : {};
                $$('[name]', form).forEach(function (inp) {
                    if (inp.name === 'csrf' || inp.name === 'aksi') return;
                    if (Object.prototype.hasOwnProperty.call(data, inp.name)) inp.value = data[inp.name];
                });
                var judul = $('[data-modal-title]', m);
                if (judul && el.getAttribute('data-title')) judul.textContent = el.getAttribute('data-title');
                var aksi = $('input[name=aksi]', form);
                if (aksi && el.getAttribute('data-aksi')) aksi.value = el.getAttribute('data-aksi');
            }
            modal(m, true);
        });
    });
    $$('[data-modal-close]').forEach(function (el) {
        el.addEventListener('click', function () { modal(el.closest('.modal'), false); });
    });
    document.addEventListener('keydown', function (ev) {
        if (ev.key === 'Escape') { $$('.modal.open').forEach(function (m) { modal(m, false); }); }
    });

    /* Konfirmasi sebelum submit */
    var cm = $('#confirm-modal'), pending = null;
    $$('form[data-confirm]').forEach(function (f) {
        f.addEventListener('submit', function (ev) {
            if (f.dataset.ok === '1') return;
            ev.preventDefault();
            pending = f;
            $('#confirm-judul').textContent = f.getAttribute('data-confirm-title') || 'Lanjutkan tindakan ini?';
            $('#confirm-teks').textContent = f.getAttribute('data-confirm');
            modal(cm, true);
        });
    });
    var ok = $('#confirm-ok');
    if (ok) ok.addEventListener('click', function () { if (pending) { pending.dataset.ok = '1'; pending.submit(); } });

    /* Filter tabel / daftar langsung */
    $$('[data-filter]').forEach(function (inp) {
        inp.addEventListener('input', function () {
            var q = inp.value.toLowerCase().trim();
            $$(inp.getAttribute('data-filter')).forEach(function (row) {
                row.style.display = row.textContent.toLowerCase().indexOf(q) > -1 ? '' : 'none';
            });
            var kosong = $(inp.getAttribute('data-empty') || '#none');
            if (kosong) {
                var tampil = $$(inp.getAttribute('data-filter')).some(function (r) { return r.style.display !== 'none'; });
                kosong.classList.toggle('hidden', tampil);
            }
        });
    });

    /* Tampilkan / sembunyikan password */
    $$('[data-pass-toggle]').forEach(function (b) {
        b.addEventListener('click', function () {
            var i = $(b.getAttribute('data-pass-toggle'));
            if (i) i.type = i.type === 'password' ? 'text' : 'password';
        });
    });
})();
</script>
</body>
</html>
