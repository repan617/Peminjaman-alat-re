<?php
$level_boleh = ['petugas'];
require_once '../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_cek();
    $aksi = isset($_POST['aksi']) ? $_POST['aksi'] : '';
    $id   = (int)(isset($_POST['id_peminjaman']) ? $_POST['id_peminjaman'] : 0);
    if ($aksi === 'setujui' || $aksi === 'tolak') {
        $hasil = proses_persetujuan($koneksi, $id, $aksi, $user['nama']);
    } elseif ($aksi === 'kembali') {
        $hasil = proses_pengembalian($koneksi, $id, $user['nama']);
    } else {
        $hasil = [false, 'Aksi tidak dikenal.'];
    }
    flash_set($hasil[0] ? 'success' : 'error', $hasil[1]);
    redirect('petugas/dashboard.php');
}

$menunggu   = (int)db_val($koneksi, 'SELECT COUNT(*) FROM peminjaman WHERE persetujuan = 0');
$dipinjam   = (int)db_val($koneksi, 'SELECT COUNT(*) FROM peminjaman WHERE persetujuan = 1 AND status = 1');
$terlambat  = (int)db_val($koneksi, 'SELECT COUNT(*) FROM peminjaman WHERE persetujuan = 1 AND status = 1 AND tanggal_kembali < CURDATE()');
$kembali_hr = (int)db_val($koneksi, 'SELECT COUNT(*) FROM pengembalian WHERE tanggal_kembali = CURDATE()');

$antrean = db_all($koneksi, 'SELECT p.*, u.nama AS peminjam, a.nama_alat, a.stok, a.id_kategori, k.nama_kategori
                             FROM peminjaman p
                             JOIN user u ON u.id_user = p.id_user
                             JOIN alat a ON a.id_alat = p.id_alat
                             JOIN kategori k ON k.id_kategori = a.id_kategori
                             WHERE p.persetujuan = 0 ORDER BY p.id_peminjaman ASC LIMIT 4');

$jatuh_tempo = db_all($koneksi, 'SELECT p.*, u.nama AS peminjam, a.nama_alat
                                 FROM peminjaman p
                                 JOIN user u ON u.id_user = p.id_user
                                 JOIN alat a ON a.id_alat = p.id_alat
                                 WHERE p.persetujuan = 1 AND p.status = 1 AND p.tanggal_kembali <= DATE_ADD(CURDATE(), INTERVAL 2 DAY)
                                 ORDER BY p.tanggal_kembali ASC LIMIT 6');

$judul = 'Dashboard';
require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>

<div class="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
    <div>
        <h2 class="text-2xl font-extrabold text-neutral-900">Dashboard</h2>
        <p class="mt-1 text-sm text-neutral-500">
            Halo, <?= e(explode(' ', $user['nama'])[0]) ?>. <?= $menunggu > 0 ? 'Ada ' . $menunggu . ' pengajuan yang menunggu keputusan Anda.' : 'Tidak ada antrean persetujuan.' ?>
        </p>
    </div>
    <div class="flex gap-2">
        <a href="<?= url('petugas/pengembalian.php') ?>" class="btn btn-ghost"><?= icon('return', 'w-4 h-4') ?> Pengembalian</a>
        <a href="<?= url('petugas/setujui.php') ?>" class="btn btn-primary"><?= icon('check', 'w-4 h-4') ?> Buka persetujuan</a>
    </div>
</div>

<section class="card mt-6 grid grid-cols-2 divide-neutral-200 max-lg:divide-y lg:grid-cols-4 lg:divide-x">
    <?php foreach ([
        ['Menunggu', $menunggu],
        ['Sedang dipinjam', $dipinjam],
        ['Terlambat', $terlambat],
        ['Kembali hari ini', $kembali_hr],
    ] as $s): ?>
        <div class="p-5">
            <p class="text-sm text-neutral-500"><?= e($s[0]) ?></p>
            <p class="mt-1 text-3xl font-semibold tabular-nums <?= $s[0] === 'Terlambat' && (int)$s[1] > 0 ? 'text-danger-600' : 'text-neutral-900' ?>"><?= (int)$s[1] ?></p>
        </div>
    <?php endforeach; ?>
</section>

<section class="mt-8 grid gap-6 xl:grid-cols-[1.5fr_1fr]">
    <div>
        <div class="mb-3 flex items-center justify-between">
            <h3 class="text-base font-semibold text-neutral-900">Antrean persetujuan</h3>
            <a href="<?= url('petugas/setujui.php') ?>" class="text-sm font-medium text-accent-700 hover:underline">Lihat semua</a>
        </div>
        <div class="card divide-y divide-neutral-100">
            <?php foreach ($antrean as $r): ?>
                <article class="flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
                    <div class="min-w-0 flex-1">
                        <p class="text-sm font-medium text-neutral-900"><?= e($r['nama_alat']) ?> <span class="font-normal text-neutral-500">oleh</span> <?= e($r['peminjam']) ?></p>
                        <p class="text-sm text-neutral-500"><?= tgl($r['tanggal_pinjam']) ?> sampai <?= tgl($r['tanggal_kembali']) ?> · stok <?= (int)$r['stok'] ?></p>
                    </div>
                    <div class="flex gap-2">
                        <form method="post"><?= csrf_field() ?><input type="hidden" name="aksi" value="setujui"><input type="hidden" name="id_peminjaman" value="<?= (int)$r['id_peminjaman'] ?>"><button class="btn btn-primary btn-sm"><?= icon('check', 'w-4 h-4') ?> Setujui</button></form>
                        <form method="post" data-confirm="Pengajuan <?= e($r['nama_alat']) ?> oleh <?= e($r['peminjam']) ?> akan ditolak." data-confirm-title="Tolak pengajuan?"><?= csrf_field() ?><input type="hidden" name="aksi" value="tolak"><input type="hidden" name="id_peminjaman" value="<?= (int)$r['id_peminjaman'] ?>"><button class="btn btn-danger-soft btn-sm">Tolak</button></form>
                    </div>
                </article>
            <?php endforeach; ?>
            <?php if (!$antrean): ?>
                <div class="py-12 text-center">
                    <p class="text-sm font-medium text-neutral-900">Antrean kosong</p>
                    <p class="mt-1 text-sm text-neutral-500">Pengajuan baru akan muncul di sini.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div>
        <h3 class="mb-3 text-base font-semibold text-neutral-900">Jatuh tempo 2 hari ke depan</h3>
        <div class="card divide-y divide-neutral-100">
            <?php foreach ($jatuh_tempo as $r):
                $telat = $r['tanggal_kembali'] < date('Y-m-d');
                $d = abs(hari_selisih(date('Y-m-d'), $r['tanggal_kembali'])); ?>
                <div class="flex items-center gap-3 p-4">
                    <div class="min-w-0 flex-1">
                        <p class="truncate text-sm font-medium text-neutral-900"><?= e($r['nama_alat']) ?></p>
                        <p class="text-xs text-neutral-500"><?= e($r['peminjam']) ?> · <?= tgl($r['tanggal_kembali']) ?></p>
                    </div>
                    <?= $telat ? badge('Telat ' . $d . ' hari', 'red') : badge($d === 0 ? 'Hari ini' : $d . ' hari lagi', 'amber') ?>
                </div>
            <?php endforeach; ?>
            <?php if (!$jatuh_tempo): ?><p class="p-6 text-center text-sm text-neutral-500">Tidak ada yang mendekati jatuh tempo.</p><?php endif; ?>
        </div>
    </div>
</section>

<?php require_once '../includes/footer.php'; ?>
