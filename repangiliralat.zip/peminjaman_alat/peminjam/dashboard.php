<?php
$level_boleh = ['peminjam'];
require_once '../includes/auth.php';

$id = $user['id'];
$aktif     = (int)db_val($koneksi, 'SELECT COUNT(*) FROM peminjaman WHERE id_user = ? AND persetujuan = 1 AND status = 1', [$id]);
$menunggu  = (int)db_val($koneksi, 'SELECT COUNT(*) FROM peminjaman WHERE id_user = ? AND persetujuan = 0', [$id]);
$selesai   = (int)db_val($koneksi, 'SELECT COUNT(*) FROM peminjaman WHERE id_user = ? AND status = 2', [$id]);

$kategori = db_all($koneksi, 'SELECT k.*, COUNT(a.id_alat) AS jenis FROM kategori k LEFT JOIN alat a ON a.id_kategori = k.id_kategori GROUP BY k.id_kategori ORDER BY k.nama_kategori');
$pilihan = db_all($koneksi, "SELECT a.*, k.nama_kategori FROM alat a JOIN kategori k ON k.id_kategori = a.id_kategori
                             WHERE a.stok > 0 AND a.kondisi NOT LIKE '%berat%'
                             ORDER BY (SELECT COUNT(*) FROM peminjaman p WHERE p.id_alat = a.id_alat) DESC, a.nama_alat LIMIT 4");
$pinjaman = db_all($koneksi, 'SELECT p.*, a.nama_alat, a.id_kategori, k.nama_kategori
                              FROM peminjaman p JOIN alat a ON a.id_alat = p.id_alat JOIN kategori k ON k.id_kategori = a.id_kategori
                              WHERE p.id_user = ? AND ((p.persetujuan = 1 AND p.status = 1) OR p.persetujuan = 0)
                              ORDER BY p.tanggal_kembali ASC LIMIT 4', [$id]);

$judul = 'Beranda';
require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>

<div class="mx-auto max-w-6xl px-4 py-8 sm:px-6">

    <!-- Hero + pencarian -->
    <section class="relative overflow-hidden rounded-3xl border-2 border-neutral-900 p-6 shadow-pop sm:p-10" style="background:#FFD84D">
        <span class="pointer-events-none absolute -right-10 -top-12 hidden h-56 w-56 rounded-full border-2 border-neutral-900 sm:block" style="background:#FF7A45"></span>
        <span class="pointer-events-none absolute bottom-6 right-24 hidden h-16 w-16 rotate-12 rounded-xl border-2 border-neutral-900 bg-white sm:block"></span>
        <div class="relative max-w-xl">
            <p class="inline-block -rotate-1 rounded-md border-2 border-neutral-900 bg-white px-2.5 py-1 font-mono text-[11px] font-medium uppercase tracking-[.14em]">Gilir · pinjam bergiliran</p>
            <h1 class="mt-4 text-4xl font-extrabold leading-tight text-neutral-900 sm:text-5xl">Halo, <?= e(explode(' ', $user['nama'])[0]) ?>! Giliran alat apa hari ini?</h1>
            <p class="mt-3 text-sm font-medium text-neutral-800 sm:text-base">Pilih alat, tentukan tanggalnya, lalu tunggu persetujuan petugas.</p>
            <form action="daftar_alat.php" method="get" class="mt-6 flex gap-2">
                <div class="relative flex-1">
                    <span class="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-500"><?= icon('search', 'w-4 h-4') ?></span>
                    <input type="search" name="q" class="input pl-10" placeholder="Cari laptop, proyektor, kamera" aria-label="Cari alat">
                </div>
                <button class="btn btn-dark">Cari</button>
            </form>
        </div>
    </section>

    <!-- Ringkasan -->
    <section class="mt-6 grid grid-cols-3 gap-3 sm:gap-4">
        <?php foreach ([['Sedang dipinjam', $aktif, 'clipboard'], ['Menunggu', $menunggu, 'clock'], ['Selesai', $selesai, 'check']] as $s): ?>
            <div class="card p-4 sm:p-5">
                <div class="flex items-center justify-between">
                    <p class="text-xs font-medium text-neutral-500 sm:text-sm"><?= e($s[0]) ?></p>
                    <span class="icon-tile hidden h-8 w-8 sm:grid"><?= icon($s[2], 'w-4 h-4') ?></span>
                </div>
                <p class="mt-1 text-3xl font-extrabold tabular-nums text-gradient sm:text-4xl"><?= (int)$s[1] ?></p>
            </div>
        <?php endforeach; ?>
    </section>

    <!-- Pinjaman saya -->
    <?php if ($pinjaman): ?>
    <section class="mt-10">
        <div class="flex items-end justify-between">
            <h2 class="text-lg font-bold text-neutral-900">Pinjaman saya</h2>
            <a href="<?= url('peminjam/riwayat.php') ?>" class="text-sm font-medium text-accent-700 hover:underline">Semua riwayat</a>
        </div>
        <div class="card mt-3 divide-y divide-neutral-100">
            <?php foreach ($pinjaman as $p):
                $telat = (int)$p['persetujuan'] === 1 && $p['tanggal_kembali'] < date('Y-m-d');
                $sisa = hari_selisih(date('Y-m-d'), $p['tanggal_kembali']); ?>
                <article class="flex items-center gap-4 p-4">
                    <span class="icon-tile h-10 w-10"><?= icon(kategori_ikon($p['nama_kategori']), 'w-5 h-5') ?></span>
                    <div class="min-w-0 flex-1">
                        <h3 class="truncate text-sm font-medium text-neutral-900"><?= e($p['nama_alat']) ?></h3>
                        <p class="text-sm <?= $telat ? 'text-danger-600' : 'text-neutral-500' ?>">
                            <?php if ((int)$p['persetujuan'] === 0): ?>Diajukan untuk <?= tgl($p['tanggal_pinjam']) ?>
                            <?php elseif ($telat): ?>Seharusnya kembali <?= tgl($p['tanggal_kembali']) ?>
                            <?php else: ?>Kembalikan <?= $sisa <= 0 ? 'hari ini' : 'dalam ' . $sisa . ' hari' ?><?php endif; ?>
                        </p>
                    </div>
                    <?= badge_status($p) ?>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- Kategori -->
    <section class="mt-10">
        <div class="flex items-end justify-between">
            <h2 class="text-lg font-bold text-neutral-900">Kategori</h2>
            <a href="<?= url('peminjam/daftar_alat.php') ?>" class="text-sm font-medium text-accent-700 hover:underline">Lihat semua alat</a>
        </div>
        <div class="mt-3 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-5">
            <?php foreach ($kategori as $k): ?>
                <a href="<?= url('peminjam/daftar_alat.php?kategori=' . (int)$k['id_kategori']) ?>" class="card flex items-center gap-3 p-4 transition-colors hover:border-neutral-300 hover:bg-neutral-50">
                    <span class="icon-tile h-9 w-9" style="<?= kategori_gradien($k['id_kategori']) ?>"><?= icon(kategori_ikon($k['nama_kategori']), 'w-[18px] h-[18px]') ?></span>
                    <span class="min-w-0 leading-tight">
                        <span class="block truncate text-sm font-medium text-neutral-900"><?= e($k['nama_kategori']) ?></span>
                        <span class="text-xs text-neutral-500"><?= (int)$k['jenis'] ?> jenis alat</span>
                    </span>
                </a>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Pilihan populer -->
    <section class="mt-10">
        <h2 class="text-lg font-bold text-neutral-900">Paling sering dipinjam</h2>
        <p class="mt-0.5 text-sm text-neutral-500">Alat yang tersedia dan paling banyak diminta.</p>
        <div class="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <?php foreach ($pilihan as $i => $a) { echo kartu_alat($a, $i * 70); } ?>
        </div>
        <?php if (!$pilihan): ?><div class="card py-12 text-center text-sm text-neutral-500">Belum ada alat yang tersedia.</div><?php endif; ?>
    </section>

    <!-- Alur -->
    <section class="card mt-10 p-6">
        <h2 class="text-lg font-bold text-neutral-900">Tiga langkah meminjam</h2>
        <ol class="mt-4 grid gap-5 md:grid-cols-3">
            <?php foreach ([
                ['Pilih alat', 'Cari di katalog, lalu tekan Pinjam pada alat yang kamu perlukan.'],
                ['Tunggu persetujuan', 'Petugas memeriksa stok dan menyetujui pengajuanmu.'],
                ['Ambil dan kembalikan', 'Ambil alatnya, lalu kembalikan sebelum batas tanggal.'],
            ] as $n => $st): ?>
                <li class="flex gap-3">
                    <span class="grid h-8 w-8 shrink-0 place-items-center rounded-full border-2 border-neutral-900 bg-accent-400 font-display text-sm font-extrabold text-neutral-900"><?= $n + 1 ?></span>
                    <div>
                        <p class="text-sm font-medium text-neutral-900"><?= e($st[0]) ?></p>
                        <p class="mt-0.5 text-sm leading-relaxed text-neutral-500"><?= e($st[1]) ?></p>
                    </div>
                </li>
            <?php endforeach; ?>
        </ol>
    </section>
</div>

<?php require_once '../includes/footer.php'; ?>
