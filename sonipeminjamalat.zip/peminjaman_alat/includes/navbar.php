<?php
/**
 * includes/navbar.php
 * Satu navbar atas untuk semua level (admin, petugas, peminjam).
 * Wajib setelah header.php dan auth.php.
 */
$menu_aktif = basename($_SERVER['SCRIPT_NAME'], '.php');

$menus = [
    'admin' => [
        ['dashboard', 'Dashboard', 'grid'],
        ['user', 'Pengguna', 'users'],
        ['kategori', 'Kategori', 'tag'],
        ['alat', 'Data Alat', 'box'],
        ['peminjaman', 'Peminjaman', 'clipboard'],
        ['pengembalian', 'Pengembalian', 'return'],
        ['log_aktivitas', 'Log Aktivitas', 'activity'],
    ],
    'petugas' => [
        ['dashboard', 'Dashboard', 'grid'],
        ['peminjaman', 'Data Peminjaman', 'clipboard'],
        ['setujui', 'Persetujuan', 'check'],
        ['pengembalian', 'Pengembalian', 'return'],
        ['cetak', 'Cetak Laporan', 'printer'],
    ],
    'peminjam' => [
        ['dashboard', 'Beranda', 'home'],
        ['daftar_alat', 'Katalog Alat', 'grid'],
        ['pinjam', 'Ajukan Pinjam', 'plus'],
        ['riwayat', 'Riwayat', 'clock'],
    ],
];
$menu = $menus[$user['level']];

$jumlah_menunggu = 0;
if ($user['level'] !== 'peminjam') {
    $jumlah_menunggu = (int)db_val($koneksi, 'SELECT COUNT(*) FROM peminjaman WHERE persetujuan = 0');
}

function logo_svg($kelas = 'w-9 h-9')
{
    return '<span class="grid place-items-center rounded-xl shadow-glow ' . $kelas . '" style="background-image:linear-gradient(135deg,#10B981,#22D3EE)">'
        . '<svg viewBox="0 0 24 24" class="h-[60%] w-[60%]" fill="none" stroke="#fff" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round"><path d="M8 20V5h5.5a4.25 4.25 0 0 1 0 8.5H8"/></svg></span>';
}
?>

<header class="no-print glass sticky top-0 z-40 border-b border-white/10">
    <div class="mx-auto flex h-16 max-w-6xl items-center gap-6 px-4 sm:px-6">
        <a href="<?= url($user['level'] . '/dashboard.php') ?>" class="flex items-center gap-2.5">
            <?= logo_svg() ?>
            <span class="text-lg font-extrabold tracking-tight text-neutral-900">Pinjamin<span class="text-gradient">.</span></span>
        </a>

        <nav class="hidden flex-1 items-center gap-1 lg:flex" aria-label="Menu utama">
            <?php foreach ($menu as $m):
                $on = $menu_aktif === $m[0];
                $notif = ($m[0] === 'setujui' || ($user['level'] === 'admin' && $m[0] === 'peminjaman')) && $jumlah_menunggu > 0;
            ?>
                <a href="<?= url($user['level'] . '/' . $m[0] . '.php') ?>" class="tab <?= $on ? 'tab-on' : '' ?>" <?= $on ? 'aria-current="page"' : '' ?>>
                    <?= e($m[1]) ?>
                    <?php if ($notif): ?><span class="grid h-5 min-w-[1.25rem] place-items-center rounded-full px-1.5 text-[11px] font-bold text-white shadow-glow" style="background-image:linear-gradient(135deg,#10B981,#22D3EE)"><?= $jumlah_menunggu ?></span><?php endif; ?>
                </a>
            <?php endforeach; ?>
        </nav>

        <div class="ml-auto flex items-center gap-4">
            <div class="hidden items-center gap-3 sm:flex">
                <span class="grid h-9 w-9 place-items-center rounded-full text-xs font-bold text-[#04130F]" style="background-image:linear-gradient(135deg,#34D399,#22D3EE)"><?= e(inisial($user['nama'])) ?></span>
                <div class="leading-tight">
                    <p class="text-sm font-semibold text-neutral-900"><?= e($user['nama']) ?></p>
                    <p class="text-xs capitalize text-neutral-500"><?= e($user['level']) ?></p>
                </div>
                <a href="<?= url('auth/logout.php') ?>" class="btn btn-ghost btn-sm" title="Keluar"><?= icon('logout', 'w-4 h-4') ?> Keluar</a>
            </div>
            <button type="button" class="grid h-10 w-10 place-items-center self-center rounded-xl border border-neutral-200 bg-white/5 text-neutral-700 lg:hidden" data-toggle="#menu-mobile" aria-label="Buka menu"><?= icon('menu', 'w-5 h-5') ?></button>
        </div>
    </div>

    <div id="menu-mobile" class="glass hidden border-t border-neutral-200/70 px-4 pb-4 pt-3 lg:hidden">
        <?php foreach ($menu as $m):
            $on = $menu_aktif === $m[0];
            $notif = ($m[0] === 'setujui' || ($user['level'] === 'admin' && $m[0] === 'peminjaman')) && $jumlah_menunggu > 0;
        ?>
            <a href="<?= url($user['level'] . '/' . $m[0] . '.php') ?>" class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium <?= $on ? 'bg-accent-50 text-accent-700' : 'text-neutral-700 hover:bg-neutral-100' ?>">
                <?= icon($m[2], 'w-[18px] h-[18px]') ?> <span class="flex-1"><?= e($m[1]) ?></span>
                <?php if ($notif): ?><span class="grid h-5 min-w-[1.25rem] place-items-center rounded-full px-1.5 text-[11px] font-bold text-white shadow-glow" style="background-image:linear-gradient(135deg,#10B981,#22D3EE)"><?= $jumlah_menunggu ?></span><?php endif; ?>
            </a>
        <?php endforeach; ?>
        <div class="mt-2 flex items-center justify-between border-t border-neutral-200 pt-3">
            <span class="text-sm text-neutral-700"><?= e($user['nama']) ?> <span class="text-neutral-400">· <?= e($user['level']) ?></span></span>
            <a href="<?= url('auth/logout.php') ?>" class="btn btn-ghost btn-sm"><?= icon('logout', 'w-4 h-4') ?> Keluar</a>
        </div>
    </div>
</header>
<main class="<?= $user['level'] === 'peminjam' ? 'min-h-[70vh]' : 'mx-auto min-h-[70vh] max-w-6xl px-4 py-8 sm:px-6' ?>">
