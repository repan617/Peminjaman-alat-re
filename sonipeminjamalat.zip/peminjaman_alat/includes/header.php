<?php
/**
 * includes/header.php  →  <head> + Tailwind CDN + sistem desain
 * Variabel opsional sebelum include:
 *   $judul       judul halaman
 *   $body_class  kelas tambahan untuk <body>
 */
$judul = isset($judul) ? $judul : 'Beranda';
$body_class = isset($body_class) ? $body_class : 'bg-neutral-50';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($judul) ?> · Pinjamin</title>
    <meta name="theme-color" content="#070B14">
    <meta name="color-scheme" content="dark">
    <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0' stop-color='%234F46E5'/%3E%3Cstop offset='1' stop-color='%237C3AED'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='32' height='32' rx='9' fill='url(%23g)'/%3E%3Cpath d='M10 23V9h6.2a4.3 4.3 0 0 1 0 8.6H10' fill='none' stroke='%23fff' stroke-width='3' stroke-linejoin='round'/%3E%3C/svg%3E">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@500&display=swap" rel="stylesheet">

    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Space Grotesk"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace']
                    },
                    colors: {
                        /* Skala netral DIBALIK untuk mode gelap: 50 = paling gelap, 900 = paling terang */
                        neutral: {50:'#070B14',100:'#0E1524',200:'#1B2538',300:'#2A3750',400:'#64748B',500:'#8B9BB4',600:'#A9B6CB',700:'#CBD5E1',800:'#E2E8F0',900:'#F8FAFC',950:'#FFFFFF'},
                        accent: {50:'#06231F',100:'#0A3A33',200:'#0F5A4D',300:'#14806C',400:'#2DD4BF',500:'#14B8A6',600:'#10B981',700:'#5EEAD4',800:'#99F6E4',900:'#CCFBF1'},
                        warn: {100:'#3A2A06',300:'#8A6410',400:'#FBBF24',500:'#F59E0B',600:'#FCD34D'},
                        danger: {50:'#2A0D14',100:'#4A1521',500:'#FB7185',600:'#F43F5E',700:'#E11D48'}
                    },
                    boxShadow: {
                        soft: '0 1px 0 rgba(255,255,255,.04) inset, 0 20px 40px -20px rgba(0,0,0,.7)',
                        glow: '0 0 24px -4px rgba(16,185,129,.55)'
                    }
                }
            }
        };
    </script>

    <style type="text/tailwindcss">
        @layer base {
            html { -webkit-tap-highlight-color: transparent; scroll-behavior: smooth; color-scheme: dark; }
            body { @apply font-sans text-neutral-800 antialiased; }
            h1, h2, h3 { letter-spacing: -0.025em; }
            ::selection { background: #0F5A4D; color: #CCFBF1; }
            :focus-visible { outline: 2px solid #2DD4BF; outline-offset: 2px; }
        }
        @layer components {
            .btn { @apply inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold tracking-tight transition-all duration-200 disabled:opacity-50 disabled:pointer-events-none whitespace-nowrap active:scale-[.97]; }
            .btn-sm { @apply px-3 py-1.5 text-xs gap-1.5; }
            .btn-primary, .btn-saffron { color: #04130F; background-image: linear-gradient(135deg, #34D399 0%, #22D3EE 100%); box-shadow: 0 0 0 1px rgba(255,255,255,.15) inset, 0 8px 24px -8px rgba(34,211,238,.55); }
            .btn-primary:hover, .btn-saffron:hover { filter: brightness(1.1); box-shadow: 0 0 0 1px rgba(255,255,255,.25) inset, 0 12px 30px -8px rgba(34,211,238,.75); }
            .btn-dark { background: #E2E8F0; color: #0B1220; }
            .btn-dark:hover { background: #fff; }
            .btn-soft { @apply bg-accent-100 text-accent-700 hover:bg-accent-200; }
            .btn-ghost { background: rgba(255,255,255,.04); color: #CBD5E1; border: 1px solid rgba(255,255,255,.1); }
            .btn-ghost:hover { background: rgba(255,255,255,.09); border-color: rgba(45,212,191,.45); color: #fff; }
            .btn-danger { background: #E11D48; color: #fff; box-shadow: 0 0 20px -6px rgba(244,63,94,.7); }
            .btn-danger:hover { background: #F43F5E; }
            .btn-danger-soft { background: rgba(244,63,94,.08); color: #FB7185; border: 1px solid rgba(244,63,94,.3); }
            .btn-danger-soft:hover { background: rgba(244,63,94,.16); }
            .input { @apply w-full rounded-lg px-3.5 py-2.5 text-sm text-neutral-900 placeholder:text-neutral-400 transition-all focus:outline-none; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.12); }
            .input:focus { border-color: #2DD4BF; background: rgba(45,212,191,.06); box-shadow: 0 0 0 3px rgba(45,212,191,.18); }
            select.input option { background: #0E1524; color: #E2E8F0; }
            .label { @apply mb-1.5 block text-[11px] font-semibold uppercase tracking-[.14em] text-neutral-500; }
            .card { @apply rounded-xl backdrop-blur-md; background: linear-gradient(180deg, rgba(255,255,255,.055), rgba(255,255,255,.02)); border: 1px solid rgba(255,255,255,.08); box-shadow: 0 1px 0 rgba(255,255,255,.04) inset, 0 24px 48px -24px rgba(0,0,0,.8); }
            a.card, article.card { @apply transition-all duration-300; }
            a.card:hover, article.card:hover { border-color: rgba(45,212,191,.5); box-shadow: 0 0 0 1px rgba(45,212,191,.15), 0 0 32px -8px rgba(45,212,191,.35); }
            .badge { @apply inline-flex items-center gap-1.5 whitespace-nowrap rounded-md px-2 py-0.5 font-mono text-[11px] font-medium uppercase tracking-wide; border: 1px solid transparent; }
            .badge i { @apply block h-1.5 w-1.5 rounded-full bg-current; box-shadow: 0 0 8px currentColor; }
            .badge-amber { color: #FCD34D; background: rgba(245,158,11,.12); border-color: rgba(245,158,11,.3); }
            .badge-green { color: #6EE7B7; background: rgba(16,185,129,.12); border-color: rgba(16,185,129,.3); }
            .badge-red { color: #FDA4AF; background: rgba(244,63,94,.12); border-color: rgba(244,63,94,.3); }
            .badge-blue { color: #67E8F9; background: rgba(34,211,238,.12); border-color: rgba(34,211,238,.3); }
            .badge-violet { color: #04130F; background-image: linear-gradient(135deg, #34D399, #22D3EE); }
            .badge-gray { color: #A9B6CB; background: rgba(255,255,255,.05); border-color: rgba(255,255,255,.1); }
            .tbl { @apply w-full text-sm; }
            .tbl th { @apply whitespace-nowrap px-5 py-3 text-left font-mono text-[11px] font-medium uppercase tracking-[.14em] text-neutral-500; background: rgba(255,255,255,.03); border-bottom: 1px solid rgba(255,255,255,.08); }
            .tbl td { @apply px-5 py-3.5 align-middle; border-top: 1px solid rgba(255,255,255,.05); }
            .tbl tbody tr:first-child td { border-top: 0; }
            .tbl tbody tr { @apply transition-colors; }
            .tbl tbody tr:hover { background: rgba(45,212,191,.06); }
            .chip { @apply inline-flex items-center gap-1.5 rounded-md px-3.5 py-1.5 text-sm font-medium text-neutral-600 transition-all; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.1); }
            .chip:hover { border-color: rgba(45,212,191,.5); color: #5EEAD4; }
            .chip-on, .chip-on:hover { color: #04130F; border-color: transparent; background-image: linear-gradient(135deg, #34D399, #22D3EE); box-shadow: 0 0 20px -6px rgba(34,211,238,.6); }
            .tab { @apply relative flex h-9 items-center gap-2 self-center whitespace-nowrap rounded-lg px-3.5 text-sm font-medium text-neutral-500 transition-all hover:text-neutral-900; }
            .tab:hover { background: rgba(255,255,255,.05); }
            .tab-on, .tab-on:hover { color: #5EEAD4; background: rgba(45,212,191,.1); box-shadow: 0 0 0 1px rgba(45,212,191,.28) inset; }
            .icon-tile { @apply grid shrink-0 place-items-center rounded-lg; color: #2DD4BF; background: rgba(45,212,191,.1); border: 1px solid rgba(45,212,191,.25); }
        }
    </style>

    <style>
        body {
            background-color: #070B14;
            background-image:
                radial-gradient(48rem 26rem at 90% -10%, rgba(34,211,238,.16), transparent 60%),
                radial-gradient(44rem 26rem at -8% 0%, rgba(16,185,129,.14), transparent 60%),
                linear-gradient(rgba(255,255,255,.025) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,.025) 1px, transparent 1px);
            background-size: auto, auto, 36px 36px, 36px 36px;
            background-attachment: fixed;
        }
        .bg-white { background-color: rgba(255,255,255,.04) !important; }
        .scroll-thin::-webkit-scrollbar { width: 6px; height: 6px; }
        .scroll-thin::-webkit-scrollbar-thumb { background: #2A3750; border-radius: 999px; }
        .text-gradient { background-image: linear-gradient(135deg, #34D399, #22D3EE); -webkit-background-clip: text; background-clip: text; color: transparent; }
        .glass { background: rgba(7,11,20,.7); -webkit-backdrop-filter: saturate(160%) blur(18px); backdrop-filter: saturate(160%) blur(18px); }
        /* Modal */
        .modal { position: fixed; inset: 0; z-index: 60; display: none; align-items: center; justify-content: center; padding: 1rem; }
        .modal.open { display: flex; }
        .modal-bg { position: absolute; inset: 0; background: rgba(2,6,14,.72); -webkit-backdrop-filter: blur(8px); backdrop-filter: blur(8px); animation: fadeIn .2s ease; }
        .modal-box { position: relative; width: 100%; max-width: 28rem; max-height: 92vh; overflow-y: auto; border-radius: .9rem; background: #0C1322; border: 1px solid rgba(45,212,191,.25); box-shadow: 0 0 60px -12px rgba(34,211,238,.3), 0 30px 60px -20px rgba(0,0,0,.8); animation: pop .25s cubic-bezier(.2,.9,.3,1.2); }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes pop { from { opacity: 0; transform: translateY(12px) scale(.97); } to { opacity: 1; transform: none; } }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: none; } }
        @keyframes toastIn { from { opacity: 0; transform: translateY(-12px) scale(.96); } to { opacity: 1; transform: none; } }
        @keyframes toastOut { to { opacity: 0; transform: translateY(-8px); } }
        .toast-auto { animation: toastIn .35s cubic-bezier(.2,.9,.3,1.2), toastOut .3s ease 4.7s forwards; }
        main > * { animation: fadeUp .55s cubic-bezier(.2,.7,.2,1) both; }
        main > *:nth-child(2) { animation-delay: .05s; }
        main > *:nth-child(3) { animation-delay: .1s; }
        main > *:nth-child(4) { animation-delay: .15s; }
        main > *:nth-child(n+5) { animation-delay: .2s; }
        /* Cetak: kembalikan ke terang (hitam di atas putih) */
        @media print { .no-print { display: none !important; } html { filter: invert(1) hue-rotate(180deg); background: #fff; } body { background: #070B14 !important; } }
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after { animation-duration: .001ms !important; transition-duration: .001ms !important; }
        }
    </style>
</head>
<body class="<?= e($body_class) ?>">
