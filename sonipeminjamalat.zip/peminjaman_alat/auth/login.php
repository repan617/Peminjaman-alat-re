<?php
require_once __DIR__ . '/../config/koneksi.php';

// Sudah login? langsung ke dashboard masing-masing.
if (!empty($_SESSION['id_user']) && !empty($_SESSION['level'])) {
    redirect(dashboard_path($_SESSION['level']));
}

$judul = 'Masuk';
$body_class = 'bg-neutral-50';
$tanpa_layout = true;
require_once __DIR__ . '/../includes/header.php';

function logo_svg_login()
{
    return '<span class="grid h-10 w-10 place-items-center rounded-xl shadow-glow" style="background-image:linear-gradient(135deg,#10B981,#22D3EE)"><svg viewBox="0 0 24 24" class="h-5 w-5" fill="none" stroke="#fff" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round"><path d="M8 20V5h5.5a4.25 4.25 0 0 1 0 8.5H8"/></svg></span>';
}
?>
<div class="grid min-h-screen lg:grid-cols-2">
    <!-- Panel merek -->
    <aside class="relative hidden overflow-hidden p-12 text-white lg:flex lg:flex-col lg:justify-between" style="background-image:linear-gradient(145deg,#022C22 0%,#10B981 50%,#22D3EE 100%)">
        <span class="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full bg-white/10 blur-3xl"></span>
        <span class="pointer-events-none absolute -bottom-32 -left-16 h-96 w-96 rounded-full bg-fuchsia-400/25 blur-3xl"></span>
        <div class="relative flex items-center gap-3">
            <span class="grid h-10 w-10 place-items-center rounded-xl bg-white/15 ring-1 ring-white/30 backdrop-blur">
                <svg viewBox="0 0 24 24" class="h-5 w-5" fill="none" stroke="#fff" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round"><path d="M8 20V5h5.5a4.25 4.25 0 0 1 0 8.5H8"/></svg>
            </span>
            <span class="text-xl font-extrabold tracking-tight">Pinjamin.</span>
        </div>
        <div class="relative max-w-md">
            <h2 class="text-4xl font-extrabold leading-tight">Kelola peminjaman alat dengan lebih cerdas.</h2>
            <p class="mt-4 text-white/75">Ajukan, setujui, dan lacak setiap alat dalam satu platform yang rapi dan real-time.</p>
            <ul class="mt-8 space-y-3 text-sm">
                <?php foreach (['Pengajuan dan persetujuan cepat', 'Stok alat selalu terpantau', 'Riwayat dan laporan siap cetak'] as $f): ?>
                    <li class="flex items-center gap-3"><span class="grid h-6 w-6 place-items-center rounded-full bg-white/15 ring-1 ring-white/25"><?= icon('check', 'w-3.5 h-3.5') ?></span><?= e($f) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <p class="relative text-xs text-white/60">© <?= date('Y') ?> Pinjamin · Sistem peminjaman alat</p>
    </aside>

    <!-- Form -->
    <div class="flex flex-col items-center justify-center px-4 py-12">
        <div class="w-full max-w-sm">
            <a href="<?= url('auth/login.php') ?>" class="mb-8 flex items-center gap-2.5 lg:hidden">
                <?= logo_svg_login() ?>
                <span class="text-xl font-extrabold tracking-tight text-neutral-900">Pinjamin<span class="text-gradient">.</span></span>
            </a>

            <h1 class="text-3xl font-extrabold text-neutral-900">Selamat datang</h1>
            <p class="mt-1.5 text-sm text-neutral-500">Masuk dengan username dan password dari admin.</p>

            <div class="card mt-8 p-6 sm:p-8">
                <form action="proses_login.php" method="post" class="space-y-5">
                    <?= csrf_field() ?>
                    <div>
                        <label class="label" for="username">Username</label>
                        <input class="input" type="text" id="username" name="username" autocomplete="username" required autofocus>
                    </div>
                    <div>
                        <label class="label" for="password">Password</label>
                        <div class="relative">
                            <input class="input pr-11" type="password" id="password" name="password" autocomplete="current-password" required>
                            <button type="button" class="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-neutral-400 transition-colors hover:bg-neutral-100 hover:text-neutral-700" data-pass-toggle="#password" aria-label="Tampilkan password"><?= icon('eye', 'w-[18px] h-[18px]') ?></button>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-full py-3">Masuk</button>
                </form>
            </div>

            <!-- Akun contoh: hapus blok ini saat aplikasi dipakai sungguhan -->
            <div class="mt-5 flex flex-wrap items-center gap-x-2 gap-y-2 text-xs text-neutral-500">
                <span>Akun contoh:</span>
                <?php foreach ([['admin', 'admin123'], ['petugas', 'petugas123'], ['peminjam', 'peminjam123']] as $ak): ?>
                    <button type="button" class="chip !px-3 !py-1 !text-xs" data-akun="<?= e($ak[0]) ?>|<?= e($ak[1]) ?>"><?= e(ucfirst($ak[0])) ?></button>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('[data-akun]').forEach(function (b) {
    b.addEventListener('click', function () {
        var p = b.getAttribute('data-akun').split('|');
        document.getElementById('username').value = p[0];
        document.getElementById('password').value = p[1];
        document.getElementById('password').focus();
    });
});
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
